decimal_number=int(input("enter a decimal number: "))
octal_number=oct(decimal_number)[2:]
print(f"Octal: {octal_number}")